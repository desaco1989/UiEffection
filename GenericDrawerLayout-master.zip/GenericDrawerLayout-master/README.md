# GenericDrawerLayout
能从上下左右拉出的抽屉布局：

![效果图](http://img.blog.csdn.net/20151108232301698 "效果图")  

仿android 5.0侧滑菜单按钮动画：

![效果图2](http://img.blog.csdn.net/20151213182533361 "效果图2")  

详见博客：

抽屉：http://blog.csdn.net/a740169405/article/details/49720973

侧滑菜单动画：http://blog.csdn.net/a740169405/article/details/50285017

感谢：  
-----------------------------------  
[NineOldAndroids](https://github.com/JakeWharton/NineOldAndroids)<br />  

License
-----------------------------------  

    Copyright (C) 2016 Matthew Lee
    Copyright (C) 2014 The Android Open Source Project

    Licensed under the Apache License, Version 2.0 (the "License");
    you may not use this file except in compliance with the License.
    You may obtain a copy of the License at

        http://www.apache.org/licenses/LICENSE-2.0

    Unless required by applicable law or agreed to in writing, software
    distributed under the License is distributed on an "AS IS" BASIS,
    WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
    See the License for the specific language governing permissions and
    limitations under the License.
